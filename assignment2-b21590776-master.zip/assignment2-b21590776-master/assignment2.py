import sys

word = sys.argv[1]                          #answer
letters = (sys.argv[2]).split(",")          #given letters
display = ["-" for i in range(len(word))]   #displays final state of word
user_chance_size = 5                        #how many guesses left
output = "You have "+str(user_chance_size)+" guesses left\n"
output += str(display)+ "\n--------------------------------------------\n"
inmodletter = []                            #before used in in mod letters
outmodletter = []                           #before used in out mod letters

mod = 1                                     # 1 is IN mod, 0 is OUT mod


run = 1

while(run == 1):
    for letter in letters:
        if(user_chance_size > 0):
            output += "Guessed word: " + letter +" "
            if(mod == 1):                                                   #in IN mode
                if(letter in word):
                    if(letter not in inmodletter):                          #in IN mode and not used before
                        output += "You are in IN mode\n"
                        output += "You have "+str(user_chance_size)+" guesses left\n"
                        for i in range(len(word)):
                            if(letter == word[i]):                          #if one of the letter in the answer and append the letter in display
                                display[i] = letter
                                inmodletter.append(letter)
                        output += str(display)+ "\n--------------------------------------------\n"

                        if('-' not in display):                             #checks display is equal to answer
                            output += "\nYou won the game"
                    else:                                                   #in IN mode and used before letter statement
                        mod = 0
                        user_chance_size -= 1
                        output += "is used in IN mode. The game turned into OUT mode\n"
                        output += "You have "+str(user_chance_size)+" guesses left\n"
                        output += str(display)+ "\n"
                        output += "--------------------------------------------\n"
                else:                                                       #if one of the letter is not in the answer and decrease the guesses
                    mod = 0
                    user_chance_size -= 1
                    output += "The game turned into OUT mode\nYou have "+str(user_chance_size)+" guesses left\n" + str(display)+ "\n--------------------------------------------\n"
            elif( mod == 0):                                                #in OUT mode
                if((letter not in outmodletter) and (letter not in word)):  #checks letter is not used before in out mode and letter is not in the answer turned into IN mode if it is true
                    outmodletter.append(letter)
                    mod = 1
                    output += "The game turned into IN mode\nYou have "+str(user_chance_size)+" guesses left\n" +str(display) + "\n--------------------------------------------\n"
                else:                                                       #if the letter used before in out mode or letter in the answer, stays the out mode
                    user_chance_size -= 1
                    output += "You are in OUT mode\n"
                    output += "You have "+str(user_chance_size)+" guesses left\n"
                    output += str(display) + "\n"
                    output += "--------------------------------------------\n"

        else:
            run = 0
    if("-" in display):                                                     #checks display is not equal to answer
        output += "\nYou finished all letters\n"
        output += "You lost the game\n"
    break

print(output)

